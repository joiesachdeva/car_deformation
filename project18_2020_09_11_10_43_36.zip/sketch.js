var banana_image,obstacle_image,back_image,monkey_running;

var backg,monkey;

var score=0;

var ground;

var banana_group;
var obstacle_group;

function preload(){
  back_image=loadImage("jungle.png");
  monkey_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  banana_image=loadImage("banana.png");
  obstacle_image=loadImage("stone.png");
  
  
}

function setup() {
  createCanvas(800, 400);
  
  backg=createsprite(0,0,800,400);
  backg.addImage(back_image);
  backg.x=backg.width/2; 
  backg.velocityX=-4;
  
  ground=createSprite(400,345,800,10);
  
  
  monkey=createSprite(100,340,20,50);
  monkey.addAnimation("running",monkey_running);
  
  banana_group=new Group();
  obstacle_group=new Group();
  
}

function draw() {
  background(220);
  
  ground.visible=false;
  monkey.collide(ground);
  
  if(ground.x<0){
   ground.x=ground.width/2;     
  }
  
    if(backg.x<0){
   backg.x=backg.width/2;     
  }
  
  
  if (banana_group.isTouching(monkey)){
    banana_group.destroyEach();
    score=score+2; 
  }
  
  switch(score){
    case 10:monkey.scale=0.12; 
      break;
    case 20:monkey.scale=0.14; 
      break;
    case 30:monkey.scale=0.16; 
      break;
    case 40:monkey.scale=0.18; 
      break;
    default:break;
  }
  
  if(obstacle_group.isTouching(monkey)){
    monkey.scale=0.2;
  }
  
  banana();
  stone();
  
  drawSprites();
  
  size(20);
  text("score"+score,500,50);
  
}

function banana() {
  if (World.frameCount%80===0) {
   var bananasprite = createSprite(600, 240, 40,10);
   bananasprite.loadImage(banana_image);
   
   bananasprite.velocityX=-7;
   bananasprite.scale=0.05;
   bananasprite.lifetime=60;
   
   bananagroup.add(bananasprite);
        
    
  }
  
  
}

function stone() {
  if (World.frameCount%300===0) {
    var stonesprite = createSprite(800,340,10,50);
    stonesprite.loadImage(obstacle_image);
    
    stonesprite.velocityX=-7;
    stonesprite.scale=0.15;
    stonesprite.lifetime=60;
    stonegroup.add(stonesprite);
    
    
  }
  
  
}
